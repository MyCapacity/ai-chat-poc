class MessageThreadContext : 
    def __init__(self, threadid:str = None):
        self.threadid = threadid