## Vector store files 
Vector store files are stored under [data](./data/)
All files under this location will automatically be deployed to the vector store when [main.py](./main.py) is executed. 

## bot instruction
The bot instruction is stored in [botinstruction.txt](./botinstruction.txt)
The bot is updated with the instruction when [main.py](./main.py) is executed. 